# Semi-Monthly Reconciliation — Unmatched Transactions Report

Runs **1st & 15th at 06:30 SAST** (04:30 UTC) + manual trigger + auto on file push.

## Folder Structure
```
/data
  /bank/           # FNB/Investec bank CSV exports
  /remits/         # Scheme remittance CSVs (ERA/EFT advice)
  ALIAS_MAP.csv    # Scheme alias → regex map
/scripts
  reconcile.py     # Aggregates & compares bank vs remits
  make_report.py   # Builds HTML + PDF
  send_email.py    # SMTP email with attachments
/.github/workflows
  reconcile-semi-monthly.yml
/out               # Generated reports
```

## Quick Start
1. Commit your CSVs to `data/bank/` and `data/remits/`.
2. (Optional) Update `data/ALIAS_MAP.csv` with your scheme regexes.
3. Push to `main` and/or click **Actions → reconcile-semi-monthly → Run workflow**.
4. Find results in the workflow **Artifacts** or in the repo `/out/` folder (if you commit them).

## Environment (for email)
Set repository **Secrets** / **Variables**:
- `SMTP_USER` (secret) — your sending mailbox (e.g., Gmail address)
- `SMTP_PASS` (secret) — app password (Gmail) or SMTP password
- `SMTP_HOST` (var) — default `smtp.gmail.com`
- `SMTP_PORT` (var) — default `465`
- `REPORT_TO_EMAIL` (var) — destination address

> If SMTP creds are absent, the workflow still builds HTML/PDF and uploads them as artifacts.

## CSV Contract (flexible)
- Bank CSV must include `Amount` and `Description` columns (case-insensitive; `Details` or `Narration` also accepted).
- Remits CSV must include `Scheme` and `Amount` columns.
- Scheme detection uses `ALIAS_MAP.csv` regexes against **bank Description** (e.g., `DISC SUPP`, `GEMS`, `FDH`, `AMS`, `BON1130900`, `BF\d+` for patients).

## Outputs
- `out/unmatched.csv` — per-scheme totals and delta
- `out/kpis.json` — totals, net delta, top gaps
- `out/unmatched.html` — color-coded table
- `out/unmatched.pdf` — printable summary

## Change Schedule
Adjust cron in `.github/workflows/reconcile-semi-monthly.yml`:
```
- cron: '30 4 5,20 * *'   # 5th & 20th at 06:30 SAST
```

## Local test
```bash
pip install -r requirements.txt
python scripts/reconcile.py --in data/bank --remits data/remits --alias data/ALIAS_MAP.csv --out out
python scripts/make_report.py out --pdf out/unmatched.pdf --html out/unmatched.html
python scripts/send_email.py --subject "Test" --to you@example.com --files out/unmatched.html out/unmatched.pdf
```
