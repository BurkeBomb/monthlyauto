#!/usr/bin/env python3
import argparse, os, smtplib, ssl, mimetypes
from email.message import EmailMessage
from pathlib import Path

def attach_files(msg: EmailMessage, files):
    for fp in files:
        path = Path(fp)
        if not path.exists(): 
            continue
        ctype, _ = mimetypes.guess_type(str(path))
        maintype, subtype = (ctype.split("/", 1) if ctype else ("application", "octet-stream"))
        with open(path, "rb") as f:
            msg.add_attachment(f.read(), maintype=maintype, subtype=subtype, filename=path.name)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--subject", required=True)
    ap.add_argument("--to", required=True)
    ap.add_argument("--files", nargs="*", default=[])
    ap.add_argument("--body", default="See attached reconciliation report.")
    args = ap.parse_args()

    user = os.getenv("SMTP_USER") or os.getenv("EMAIL_USER")
    pwd  = os.getenv("SMTP_PASS") or os.getenv("EMAIL_PASS")
    host = os.getenv("SMTP_HOST", "smtp.gmail.com")
    port = int(os.getenv("SMTP_PORT", "465"))

    if not (user and pwd):
        print("[warn] SMTP credentials not set. Skipping email send.")
        return

    msg = EmailMessage()
    msg["Subject"] = args.subject
    msg["From"] = user
    msg["To"] = args.to
    msg.set_content(args.body)

    attach_files(msg, args.files)

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(host, port, context=context) as server:
        server.login(user, pwd)
        server.send_message(msg)
        print("[ok] Email sent")

if __name__ == "__main__":
    main()
